<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller {

    public function index()
    {
        $this->load->model('Matakuliah_model','mk1');
        $this->mk1->nama="Pemrograman Web";
        $this->mk1->sks=3;
        $this->mk1->kode='0121';

        $this->load->model('Matakuliah_model','mk2');
        $this->mk2->nama="Basis Data";
        $this->mk2->sks=4;
        $this->mk2->kode='0131';

        $this->load->model('Matakuliah_model','mk3');
        $this->mk3->nama="Jaringan Komputer";
        $this->mk3->sks=3;
        $this->mk3->kode='0103';

        $list_mk = [$this->mk1, $this->mk2, $this->mk3];
        $data['list_mk']=$list_mk;

        $this->load->view('matakuliah/index',$data);
    }
}
?>